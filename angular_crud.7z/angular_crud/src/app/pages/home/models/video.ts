export class Video {
    id?: String;
    title?: String;
    hat?: String;
    author?: String;
    thumbnail?: String;
    urlVideo?: String;
    publishDate?: Date;
    status?: Number;
}