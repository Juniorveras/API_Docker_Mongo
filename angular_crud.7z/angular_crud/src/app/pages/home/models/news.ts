export class News {
    id?: String;
    title?: String;
    hat?: String;
    text?: String;
    author?: String;
    img?: String;
    publishDate?: Date;
    status?: Number;
}